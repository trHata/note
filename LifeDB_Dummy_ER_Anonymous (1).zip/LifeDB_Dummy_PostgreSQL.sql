-- PostgreSQL 14以降向け / 匿名化されたNotionスキーマの移行用DDL
-- 53本体テーブル + 91リレーション中間テーブル。レコードデータなし。
-- 新規スキーマのみ作成。既存の同名スキーマがあれば停止します。
-- Formula/Rollupは結果保存用JSONB。計算・集計は自動実行しません。
-- 双方向Relationの同期と最終更新時刻の自動更新はアプリ側で実装してください。
BEGIN;
CREATE SCHEMA "lifedb_dummy";

CREATE TABLE "lifedb_dummy"."[保険]_生命医療火災保険" (
  "_page_id" uuid PRIMARY KEY,
  "アカウント" text,
  "ウェブサイト" text,
  "パス" text,
  "使用区分" text,
  "保険ID" text,
  "保険会社" text,
  "保障概要" text,
  "備考" text,
  "区分" text,
  "名前" text,
  "商品名" text,
  "契約満了日" text,
  "契約番号、証券番号" text,
  "契約者" text,
  "契約開始日" text,
  "支払単位" text,
  "支払方法" text,
  "支払明細" numeric,
  "料金（年）" numeric,
  "料金（月）" text,
  "詳細区分" text
);
COMMENT ON TABLE "lifedb_dummy"."[保険]_生命医療火災保険" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."アカウント" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."ウェブサイト" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."パス" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."使用区分" IS 'Notion型: select / 選択肢: 利用中 | 解約';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."保険ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."保険会社" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."保障概要" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."区分" IS 'Notion型: select / 選択肢: 保険 | 個人年金';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."商品名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."契約満了日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."契約番号、証券番号" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."契約者" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."契約開始日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."支払単位" IS 'Notion型: select / 選択肢: 毎月 | 1年';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."支払方法" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."支払明細" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."料金（年）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."料金（月）" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]_生命医療火災保険"."詳細区分" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[保険]自動車保険" (
  "_page_id" uuid PRIMARY KEY,
  "事故した時の連絡先" text,
  "使用区分" text,
  "備考" text,
  "内容" text,
  "利用者" text,
  "名前" text,
  "名称" text,
  "契約満了日" jsonb,
  "契約番号、証券番号" text,
  "契約開始日" jsonb,
  "支払単位" text,
  "料金（年）" numeric,
  "料金（月）" numeric,
  "車保険ID" text
);
COMMENT ON TABLE "lifedb_dummy"."[保険]自動車保険" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."事故した時の連絡先" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."使用区分" IS 'Notion型: select / 選択肢: 利用中 | 解約 | 満了';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."利用者" IS 'Notion型: select / 選択肢: 家族';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."契約満了日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."契約番号、証券番号" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."契約開始日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."支払単位" IS 'Notion型: select / 選択肢: 1年';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."料金（年）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."料金（月）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[保険]自動車保険"."車保険ID" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[健康]_ストレスチェック" (
  "_page_id" uuid PRIMARY KEY,
  "イライラ感" numeric,
  "コース" text,
  "ストレス要因評価点" numeric,
  "上司サポート" numeric,
  "不安感" numeric,
  "仕事のコントロール度" numeric,
  "仕事の質的負担" numeric,
  "仕事の適正度" numeric,
  "仕事の量的負担" numeric,
  "仕事パフォーマンス％" numeric,
  "仕事生活満足度" numeric,
  "働きがい" numeric,
  "同僚サポート" numeric,
  "名称" text,
  "周囲のサポート評価点" numeric,
  "回答提出日時" jsonb,
  "回答開始日時" jsonb,
  "実施日" jsonb,
  "家族友人サポート" numeric,
  "対人関係ストレス" numeric,
  "年度" numeric,
  "心身の自覚症状評価点" numeric,
  "技能の活用度" numeric,
  "抑うつ感" numeric,
  "活気" numeric,
  "疲労感" numeric,
  "職場環境ストレス" numeric,
  "身体愁訴" numeric,
  "身体的負担度" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[健康]_ストレスチェック" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."イライラ感" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."コース" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."ストレス要因評価点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."上司サポート" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."不安感" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."仕事のコントロール度" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."仕事の質的負担" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."仕事の適正度" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."仕事の量的負担" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."仕事パフォーマンス％" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."仕事生活満足度" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."働きがい" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."同僚サポート" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."名称" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."周囲のサポート評価点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."回答提出日時" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."回答開始日時" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."実施日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."家族友人サポート" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."対人関係ストレス" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."年度" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."心身の自覚症状評価点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."技能の活用度" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."抑うつ感" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."活気" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."疲労感" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."職場環境ストレス" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."身体愁訴" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_ストレスチェック"."身体的負担度" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[健康]_予防接種" (
  "_page_id" uuid PRIMARY KEY,
  "ロット番号" text,
  "ワクチン名" text,
  "備考" text,
  "副反応" text,
  "医療機関" text,
  "回数" numeric,
  "接種日" jsonb,
  "次回予定日" jsonb,
  "記録名" text
);
COMMENT ON TABLE "lifedb_dummy"."[健康]_予防接種" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."ロット番号" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."ワクチン名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."副反応" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."医療機関" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."回数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."接種日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."次回予定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_予防接種"."記録名" IS 'Notion型: title';

CREATE TABLE "lifedb_dummy"."[健康]_体組成測定" (
  "_page_id" uuid PRIMARY KEY,
  "BMI" numeric,
  "Inbody点数" numeric,
  "コース" text,
  "タンパク質量kg" numeric,
  "ミネラル量kg" numeric,
  "体幹筋肉量kg" numeric,
  "体幹脂肪量kg" numeric,
  "体水分量L" numeric,
  "体脂肪率％" numeric,
  "体脂肪量kg" numeric,
  "体重kg" numeric,
  "体重調節kg" numeric,
  "内臓脂肪レベル" text,
  "右腕筋肉量kg" numeric,
  "右腕脂肪量kg" numeric,
  "右足筋肉量kg" numeric,
  "右足脂肪量kg" numeric,
  "名称" text,
  "基礎代謝量kcal" numeric,
  "実施日" jsonb,
  "左腕筋肉量kg" numeric,
  "左腕脂肪量kg" numeric,
  "左足筋肉量kg" numeric,
  "左足脂肪量kg" numeric,
  "年齢" numeric,
  "性別" text,
  "測定日時" jsonb,
  "筋肉調節kg" numeric,
  "筋肉量kg" numeric,
  "脂肪調節kg" numeric,
  "腹囲cm" numeric,
  "身長cm" numeric,
  "適正体重kg" numeric,
  "除脂肪体重kg" numeric,
  "骨格筋指数SMI" numeric,
  "骨格筋量kg" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[健康]_体組成測定" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."BMI" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."Inbody点数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."コース" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."タンパク質量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."ミネラル量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体幹筋肉量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体幹脂肪量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体水分量L" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体脂肪率％" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体脂肪量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体重kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."体重調節kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."内臓脂肪レベル" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."右腕筋肉量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."右腕脂肪量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."右足筋肉量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."右足脂肪量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."名称" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."基礎代謝量kcal" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."実施日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."左腕筋肉量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."左腕脂肪量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."左足筋肉量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."左足脂肪量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."年齢" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."性別" IS 'Notion型: select / 選択肢: 男 | 女';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."測定日時" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."筋肉調節kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."筋肉量kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."脂肪調節kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."腹囲cm" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."身長cm" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."適正体重kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."除脂肪体重kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."骨格筋指数SMI" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_体組成測定"."骨格筋量kg" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[健康]_健康診断結果" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "分類" jsonb,
  "名前" text,
  "日付" jsonb,
  "目的" text,
  "結果(テキスト)" text,
  "結果(数値)" numeric,
  "表示順" jsonb
);
COMMENT ON TABLE "lifedb_dummy"."[健康]_健康診断結果" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."分類" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."日付" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."目的" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."結果(テキスト)" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."結果(数値)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_健康診断結果"."表示順" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';

CREATE TABLE "lifedb_dummy"."[健康]_成長記録" (
  "_page_id" uuid PRIMARY KEY,
  "BMI" jsonb,
  "体重kg" numeric,
  "備考" text,
  "測定場所" text,
  "測定日" jsonb,
  "記録名" text,
  "身長cm" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[健康]_成長記録" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."BMI" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."体重kg" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."測定場所" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."測定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."記録名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_成長記録"."身長cm" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[健康]_検査項目マスタ" (
  "_page_id" uuid PRIMARY KEY,
  "分類" text,
  "分類No" numeric,
  "単位" text,
  "基準上限" numeric,
  "基準下限" numeric,
  "基準値" text,
  "基準条件" text,
  "検査項目" text,
  "表示順" numeric,
  "詳細解説" text,
  "項目No" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[健康]_検査項目マスタ" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."分類" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."分類No" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."単位" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."基準上限" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."基準下限" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."基準値" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."基準条件" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."検査項目" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."表示順" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."詳細解説" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]_検査項目マスタ"."項目No" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[健康]医療疾患管理" (
  "_page_id" uuid PRIMARY KEY,
  "Medical OS" text,
  "ステージ" text,
  "主治医" text,
  "主病院" text,
  "備考" text,
  "原発部位" text,
  "状態" text,
  "疾患" text,
  "疾患ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "管理名" text,
  "終了日" jsonb,
  "診断日" jsonb,
  "診療科" text
);
COMMENT ON TABLE "lifedb_dummy"."[健康]医療疾患管理" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."Medical OS" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."ステージ" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."主治医" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."主病院" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."原発部位" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."状態" IS 'Notion型: select / 選択肢: 治療継続中 | 経過観察 | 寛解 | 治療終了 | 疑い';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."疾患" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."疾患ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."管理名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."終了日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."診断日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療疾患管理"."診療科" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[健康]医療経過" (
  "_page_id" uuid PRIMARY KEY,
  "Markdownキー" text,
  "備考" text,
  "副作用・症状" text,
  "医師" text,
  "原資料" jsonb,
  "日付" jsonb,
  "次回予定" text,
  "治療・検査名" text,
  "病院" text,
  "種別" text,
  "経過ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "経過名" text,
  "結果・要約" text,
  "診療科" text
);
COMMENT ON TABLE "lifedb_dummy"."[健康]医療経過" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."Markdownキー" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."副作用・症状" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."医師" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."原資料" IS 'Notion型: file';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."日付" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."次回予定" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."治療・検査名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."病院" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."種別" IS 'Notion型: select / 選択肢: 診察 | 検査 | 入院 | 退院 | 薬物治療 | 放射線治療 | 手術 | 処方 | 副作用・症状 | 病状変化 | 紹介・転院 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."経過ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."経過名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."結果・要約" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[健康]医療経過"."診療科" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[分析]_用語マスタ" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "分類" text,
  "初出日" jsonb,
  "同義語・表記揺れ" text,
  "最終出現日" jsonb,
  "正規化名" text,
  "用語" text,
  "用語ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "登録日" jsonb,
  "総出現回数" jsonb,
  "説明" text
);
COMMENT ON TABLE "lifedb_dummy"."[分析]_用語マスタ" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."分類" IS 'Notion型: select / 選択肢: AI・技術 | 仕事 | 生活 | 家族 | 健康 | 金融 | 趣味 | 場所・組織 | 商品・サービス | その他';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."初出日" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."同義語・表記揺れ" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."最終出現日" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."正規化名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."用語" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."用語ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."登録日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."総出現回数" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語マスタ"."説明" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[分析]_用語履歴" (
  "_page_id" uuid PRIMARY KEY,
  "LifeLog ID" text,
  "備考" text,
  "出現回数" numeric,
  "出現日" jsonb,
  "原文抜粋" text,
  "履歴名" text,
  "文脈" text,
  "記録日時" timestamptz,
  "話者" text
);
COMMENT ON TABLE "lifedb_dummy"."[分析]_用語履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."LifeLog ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."出現回数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."出現日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."原文抜粋" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."履歴名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."文脈" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."記録日時" IS 'Notion型: created_time';
COMMENT ON COLUMN "lifedb_dummy"."[分析]_用語履歴"."話者" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[学校]_テスト" (
  "_page_id" uuid PRIMARY KEY,
  "テスト名" text,
  "テスト結果名" text,
  "偏差値" numeric,
  "備考" text,
  "受験者数" numeric,
  "学期" text,
  "実施日" jsonb,
  "平均点" numeric,
  "得点" numeric,
  "満点" numeric,
  "科目" text,
  "順位" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[学校]_テスト" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."テスト名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."テスト結果名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."偏差値" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."受験者数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."学期" IS 'Notion型: select / 選択肢: 1学期 | 2学期 | 3学期 | 前期 | 後期';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."実施日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."平均点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."得点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."満点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."科目" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_テスト"."順位" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[学校]_在籍" (
  "_page_id" uuid PRIMARY KEY,
  "ステータス" text,
  "備考" text,
  "区分" text,
  "在籍名" text,
  "学年" text,
  "年度" numeric,
  "担任" text,
  "期間" jsonb,
  "組" text
);
COMMENT ON TABLE "lifedb_dummy"."[学校]_在籍" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."ステータス" IS 'Notion型: select / 選択肢: 修了 | 通ってる';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."区分" IS 'Notion型: select / 選択肢: 幼稚園 | 小学校 | 中学校 | 高校';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."在籍名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."学年" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."年度" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."担任" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."期間" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_在籍"."組" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[学校]_学校" (
  "_page_id" uuid PRIMARY KEY,
  "Webサイト" text,
  "備考" text,
  "学校ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "学校名" text,
  "所在地" text,
  "種別" text,
  "電話番号" text
);
COMMENT ON TABLE "lifedb_dummy"."[学校]_学校" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."Webサイト" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."学校ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."学校名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."所在地" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."種別" IS 'Notion型: select / 選択肢: 保育園・幼稚園 | 小学校 | 中学校 | 高校 | 大学 | 専門学校 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_学校"."電話番号" IS 'Notion型: phone_number';

CREATE TABLE "lifedb_dummy"."[学校]_評定" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "単位数" numeric,
  "学年平均点" numeric,
  "学期" text,
  "欠課時数" numeric,
  "点数" numeric,
  "科目" text,
  "評定" numeric,
  "評定名" text
);
COMMENT ON TABLE "lifedb_dummy"."[学校]_評定" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."単位数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."学年平均点" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."学期" IS 'Notion型: select / 選択肢: 1学期 | 2学期 | 3学期 | 前期 | 後期 | 学年';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."欠課時数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."点数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."科目" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."評定" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[学校]_評定"."評定名" IS 'Notion型: title';

CREATE TABLE "lifedb_dummy"."[家計]_ふるさと納税" (
  "_page_id" uuid PRIMARY KEY,
  "3割金額" jsonb,
  "ふるさと納税ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "備考" text,
  "到着状況" text,
  "単価" jsonb,
  "単価・還元率分析" text,
  "単価基準単位" text,
  "単価基準量" numeric,
  "名前" text,
  "寄付先自治体" text,
  "寄付年" numeric,
  "寄付日" jsonb,
  "寄付金額" numeric,
  "数量" numeric,
  "数量単位" text,
  "状態" text,
  "申込サイト" text,
  "返礼品URL" text,
  "返礼品到着日" jsonb
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_ふるさと納税" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."3割金額" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."ふるさと納税ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."到着状況" IS 'Notion型: select / 選択肢: 到着済 | 未到着 | 対象外';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."単価" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."単価・還元率分析" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."単価基準単位" IS 'Notion型: select / 選択肢: Kg | g | 本 | 個 | 袋 | 食';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."単価基準量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."寄付先自治体" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."寄付年" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."寄付日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."寄付金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."数量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."数量単位" IS 'Notion型: select / 選択肢: Kg | g | 本 | 個 | 袋 | 食';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."状態" IS 'Notion型: select / 選択肢: 寄付済 | 寄付予定 | 候補 | 見送り';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."申込サイト" IS 'Notion型: select / 選択肢: 楽天ふるさと納税';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."返礼品URL" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_ふるさと納税"."返礼品到着日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';

CREATE TABLE "lifedb_dummy"."[家計]_カード明細" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "出典" text,
  "出典ページ" numeric,
  "利用店名" text,
  "利用日" jsonb,
  "区分" text,
  "名前" text,
  "金額" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_カード明細" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."出典" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."出典ページ" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."利用店名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."利用日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."区分" IS 'Notion型: select / 選択肢: 光熱水 | 食費・日用品 | 日用品 | 交通 | 自動車 | 医療 | 衣類 | 娯楽 | 住居・家具 | スポーツ | 家族個人 | 通信 | サブスク | 保険 | ふるさと納税 | 教育 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_カード明細"."金額" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[家計]_家計固定費・支払予定" (
  "_page_id" uuid PRIMARY KEY,
  "カテゴリ" text,
  "備考" text,
  "変動費フラグ" boolean,
  "支払名" text,
  "支払日" numeric,
  "支払月" text,
  "支払頻度" text,
  "有効" boolean,
  "終了日" jsonb,
  "金額" numeric,
  "開始日" jsonb
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_家計固定費・支払予定" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."カテゴリ" IS 'Notion型: select / 選択肢: 住居 | 水道光熱 | 通信 | 保険 | 教育 | 車 | サブスク | 税・公的 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."変動費フラグ" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."支払名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."支払日" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."支払月" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."支払頻度" IS 'Notion型: select / 選択肢: 毎月 | 2か月ごと | 3か月ごと | 6か月ごと | 毎年 | 不定期';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."有効" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."終了日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_家計固定費・支払予定"."開始日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';

CREATE TABLE "lifedb_dummy"."[家計]_投資保有集計" (
  "_page_id" uuid PRIMARY KEY,
  "価格基準日" jsonb,
  "保有集計名" text,
  "備考" text,
  "取引投資額増減" jsonb,
  "取引数量増減" jsonb,
  "平均取得単価" jsonb,
  "損益率" jsonb,
  "最新価格" numeric,
  "現在保有数量" jsonb,
  "現在投資元本" jsonb,
  "現在評価額" jsonb,
  "評価損益" jsonb,
  "開始保有数量" numeric,
  "開始投資元本" numeric,
  "預り区分" text
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_投資保有集計" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."価格基準日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."保有集計名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."取引投資額増減" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."取引数量増減" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."平均取得単価" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."損益率" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."最新価格" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."現在保有数量" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."現在投資元本" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."現在評価額" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."評価損益" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."開始保有数量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."開始投資元本" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資保有集計"."預り区分" IS 'Notion型: select / 選択肢: NISA成長 | NISAつみたて | 混在 | 特定 | 特定/一般 | その他';

CREATE TABLE "lifedb_dummy"."[家計]_投資原資基準残高" (
  "_page_id" uuid PRIMARY KEY,
  "保有数単位" text,
  "保有数（元集計）" numeric,
  "備考" text,
  "出典" text,
  "取得金額" numeric,
  "基準残高ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "基準残高名" text,
  "平均取得単価" numeric,
  "残高基準日" jsonb,
  "確定日" jsonb,
  "確定状態" text,
  "預り区分" text
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_投資原資基準残高" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."保有数単位" IS 'Notion型: select / 選択肢: 万口換算 | 株 | 不明';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."保有数（元集計）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."出典" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."取得金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."基準残高ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."基準残高名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."平均取得単価" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."残高基準日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."確定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."確定状態" IS 'Notion型: select / 選択肢: ユーザー確定 | 推定 | 要確認';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資原資基準残高"."預り区分" IS 'Notion型: select / 選択肢: 口座内合算 | NISA成長 | NISAつみたて | 特定 | その他';

CREATE TABLE "lifedb_dummy"."[家計]_投資取引" (
  "_page_id" uuid PRIMARY KEY,
  "キャッシュフロー" numeric,
  "備考" text,
  "入出金日" jsonb,
  "入金額" numeric,
  "出金額" numeric,
  "原資配賦メモ" text,
  "原資配賦状態" text,
  "取引ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "取引分類" text,
  "取引名" text,
  "取引種別" text,
  "取込キー" text,
  "取込元" text,
  "受渡日" jsonb,
  "受渡金額" numeric,
  "市場" text,
  "手数料" numeric,
  "投資額増減" jsonb,
  "摘要" text,
  "数量増減" numeric,
  "税額" numeric,
  "約定単価" numeric,
  "約定数量" numeric,
  "約定日" jsonb,
  "課税" text,
  "資金移動区分" text,
  "預り区分" text
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_投資取引" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."キャッシュフロー" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."入出金日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."入金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."出金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."原資配賦メモ" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."原資配賦状態" IS 'Notion型: select / 選択肢: 確定 | 未設定 | 対象外';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."取引ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."取引分類" IS 'Notion型: select / 選択肢: 売買 | 再投資 | 資金移動';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."取引名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."取引種別" IS 'Notion型: select / 選択肢: 投信金額買付 | 投信金額解約 | 分配金再投資 | 株式現物買 | 株式現物売 | 入金 | 出金';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."取込キー" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."取込元" IS 'Notion型: select / 選択肢: SBI約定履歴 | SBI円貨入出金 | 旧NISA管理Excel';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."受渡日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."受渡金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."市場" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."手数料" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."投資額増減" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."摘要" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."数量増減" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."税額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."約定単価" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."約定数量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."約定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."課税" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."資金移動区分" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_投資取引"."預り区分" IS 'Notion型: select / 選択肢: NISA成長 | NISAつみたて | 特定 | 特定/一般 | その他';

CREATE TABLE "lifedb_dummy"."[家計]_持株会取引履歴" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "利息金" numeric,
  "原文ラベル" text,
  "名前" text,
  "奨励金" numeric,
  "対象年月" text,
  "平均取得単価" numeric,
  "引出株数" numeric,
  "投資株数" numeric,
  "投資金額" numeric,
  "拠出金" numeric,
  "持分株数" numeric,
  "摘要" text,
  "繰越金額" numeric,
  "配当金" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_持株会取引履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."利息金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."原文ラベル" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."奨励金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."対象年月" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."平均取得単価" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."引出株数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."投資株数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."投資金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."拠出金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."持分株数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."摘要" IS 'Notion型: select / 選択肢: 月例 | 賞与 | 配当';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."繰越金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_持株会取引履歴"."配当金" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[家計]_給与年次" (
  "_page_id" uuid PRIMARY KEY,
  "年次" text,
  "年間介護保険料" jsonb,
  "年間健康保険料" jsonb,
  "年間厚生年金保険料" jsonb,
  "年間地方税" jsonb,
  "年間所得税" jsonb,
  "年間手取り" jsonb,
  "年間控除" jsonb,
  "年間残業時間" jsonb,
  "年間深夜時間" jsonb,
  "年間総支給" jsonb,
  "年間課税支給" jsonb,
  "年間雇用保険料" jsonb,
  "明細件数" jsonb
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_給与年次" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年次" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間介護保険料" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間健康保険料" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間厚生年金保険料" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間地方税" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間所得税" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間手取り" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間控除" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間残業時間" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間深夜時間" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間総支給" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間課税支給" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."年間雇用保険料" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与年次"."明細件数" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';

CREATE TABLE "lifedb_dummy"."[家計]_給与明細" (
  "_page_id" uuid PRIMARY KEY,
  "DC加入掛け金" numeric,
  "DC加入者掛け金 累計" numeric,
  "DC拠出前月分" numeric,
  "DC控除当月末 累計" numeric,
  "その他控除加算" numeric,
  "その他控除減算" numeric,
  "その他支給" numeric,
  "カフェテリア" numeric,
  "カフェテリア非課" numeric,
  "介護保険料" numeric,
  "健康保険料" numeric,
  "備考" text,
  "前月度調整" numeric,
  "労金(労組)" numeric,
  "厚生年金保険料" numeric,
  "厚生手当食事" numeric,
  "在宅勤務手当" numeric,
  "地方税" numeric,
  "奨励金" numeric,
  "子ども子育て支援金" numeric,
  "家族手当" numeric,
  "年" jsonb,
  "年間残業累積(原表)" numeric,
  "年間累積(原表)" numeric,
  "年間累積課税(原表)" numeric,
  "役割給" numeric,
  "所得税" numeric,
  "手取り" jsonb,
  "持株会" numeric,
  "控除" jsonb,
  "支給" jsonb,
  "支給対象月" text,
  "支給日" jsonb,
  "明細名" text,
  "残業時間" numeric,
  "深夜勤務手当" numeric,
  "深夜時間" numeric,
  "発揮給" numeric,
  "積立(労組)" numeric,
  "累積退職金P(定年)" numeric,
  "累積退職金P(自己)" numeric,
  "組合費" numeric,
  "自販機" numeric,
  "課税支給" jsonb,
  "購入(労組)" numeric,
  "超過勤務手当" numeric,
  "通勤手当非課" numeric,
  "雇用保険料" numeric,
  "食事代" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_給与明細" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."DC加入掛け金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."DC加入者掛け金 累計" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."DC拠出前月分" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."DC控除当月末 累計" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."その他控除加算" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."その他控除減算" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."その他支給" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."カフェテリア" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."カフェテリア非課" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."介護保険料" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."健康保険料" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."前月度調整" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."労金(労組)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."厚生年金保険料" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."厚生手当食事" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."在宅勤務手当" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."地方税" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."奨励金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."子ども子育て支援金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."家族手当" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."年" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."年間残業累積(原表)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."年間累積(原表)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."年間累積課税(原表)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."役割給" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."所得税" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."手取り" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."持株会" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."控除" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."支給" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."支給対象月" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."支給日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."明細名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."残業時間" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."深夜勤務手当" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."深夜時間" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."発揮給" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."積立(労組)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."累積退職金P(定年)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."累積退職金P(自己)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."組合費" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."自販機" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."課税支給" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."購入(労組)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."超過勤務手当" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."通勤手当非課" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."雇用保険料" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_給与明細"."食事代" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[家計]_資産残高履歴" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "基準日" jsonb,
  "残高" numeric,
  "記録名" text,
  "評価額" numeric,
  "通貨" text
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_資産残高履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_資産残高履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_資産残高履歴"."基準日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_資産残高履歴"."残高" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_資産残高履歴"."記録名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_資産残高履歴"."評価額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_資産残高履歴"."通貨" IS 'Notion型: select / 選択肢: JPY | USD | その他';

CREATE TABLE "lifedb_dummy"."[家計]_金融商品価格履歴" (
  "_page_id" uuid PRIMARY KEY,
  "データ元" text,
  "価格" numeric,
  "価格単位" text,
  "備考" text,
  "基準日" jsonb,
  "記録名" text
);
COMMENT ON TABLE "lifedb_dummy"."[家計]_金融商品価格履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_金融商品価格履歴"."データ元" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_金融商品価格履歴"."価格" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_金融商品価格履歴"."価格単位" IS 'Notion型: select / 選択肢: 円/1万口 | 円/株 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_金融商品価格履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_金融商品価格履歴"."基準日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[家計]_金融商品価格履歴"."記録名" IS 'Notion型: title';

CREATE TABLE "lifedb_dummy"."[生活]_イベント" (
  "_page_id" uuid PRIMARY KEY,
  "イベント名" text,
  "カテゴリ" text,
  "備考" text,
  "前回実施日" jsonb,
  "周期" text,
  "周期単位" text,
  "周期数" numeric,
  "日" numeric,
  "時刻" text,
  "曜日" text,
  "月" text,
  "有効" boolean,
  "次回予定日" jsonb
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_イベント" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."イベント名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."カテゴリ" IS 'Notion型: select / 選択肢: 家事 | 健康 | 車 | 住宅 | 契約 | 学校 | 金融 | 記念日 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."前回実施日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."周期" IS 'Notion型: select / 選択肢: 毎日 | 毎週 | 毎月 | 3か月ごと | 6か月ごと | 毎年 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."周期単位" IS 'Notion型: select / 選択肢: 日 | 週 | 月 | 年';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."周期数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."日" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."時刻" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."曜日" IS 'Notion型: select / 選択肢: 1_月 | 2_火 | 3_水 | 4_木 | 5_金 | 6_土 | 7_日';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."月" IS 'Notion型: select / 選択肢: 01_1月 | 02_2月 | 03_3月 | 04_4月 | 05_5月 | 06_6月 | 07_7月 | 08_8月 | 09_9月 | 10_10月 | 11_11月 | 12_12月';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."有効" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_イベント"."次回予定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';

CREATE TABLE "lifedb_dummy"."[生活]_サブスク" (
  "_page_id" uuid PRIMARY KEY,
  "使用区分" text,
  "備考" text,
  "内容" text,
  "分類" text,
  "名前" text,
  "名称" text,
  "契約満了日" jsonb,
  "契約開始日" jsonb,
  "契約開始日補足" text,
  "支払い" text,
  "支払単位" text,
  "支払方法" text,
  "料金（年）" numeric,
  "料金（月）" numeric,
  "更新方式" text,
  "締め日" text
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_サブスク" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."使用区分" IS 'Notion型: select / 選択肢: 利用中 | 解約';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."分類" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."契約満了日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."契約開始日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."契約開始日補足" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."支払い" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."支払単位" IS 'Notion型: select / 選択肢: 月 | 年';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."支払方法" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."料金（年）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."料金（月）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."更新方式" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_サブスク"."締め日" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[生活]_モバイル契約" (
  "_page_id" uuid PRIMARY KEY,
  "アカウント" text,
  "プラン名" text,
  "プラン概要" text,
  "モバイルID" text,
  "使用区分" text,
  "備考" text,
  "内容" text,
  "名前" text,
  "名称" text,
  "契約満了日" text,
  "契約開始日" text,
  "支払単位" text,
  "支払方法_" text,
  "料金（年）" numeric,
  "料金（月）" numeric,
  "締め日" text,
  "電話番号" text
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_モバイル契約" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."アカウント" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."プラン名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."プラン概要" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."モバイルID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."使用区分" IS 'Notion型: select / 選択肢: 利用中 | 解約';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."契約満了日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."契約開始日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."支払単位" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."支払方法_" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."料金（年）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."料金（月）" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."締め日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_モバイル契約"."電話番号" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[生活]_不動産修繕履歴" (
  "_page_id" uuid PRIMARY KEY,
  "保証期限" jsonb,
  "修繕名" text,
  "備考" text,
  "内容" text,
  "区分" text,
  "実施日" jsonb,
  "施工業者" text,
  "次回予定日" jsonb,
  "経過年月日" jsonb,
  "記録名" text,
  "費用" numeric,
  "関連ページ" text
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_不動産修繕履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."保証期限" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."修繕名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."区分" IS 'Notion型: select / 選択肢: 修繕 | リフォーム | 設備交換 | 建物工事 | 点検 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."実施日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."施工業者" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."次回予定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."経過年月日" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."記録名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."費用" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_不動産修繕履歴"."関連ページ" IS 'Notion型: url';

CREATE TABLE "lifedb_dummy"."[生活]_事業者連絡先" (
  "_page_id" uuid PRIMARY KEY,
  "Webサイト" text,
  "カテゴリ" text,
  "メール" text,
  "事業者名" text,
  "住所" text,
  "備考" text,
  "受付時間" text,
  "担当者名" text,
  "電話番号" text
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_事業者連絡先" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."Webサイト" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."カテゴリ" IS 'Notion型: select / 選択肢: 医療 | 学校 | 金融 | 保険 | 車 | 住宅 | 通信 | 公共 | 店舗 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."メール" IS 'Notion型: email';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."事業者名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."住所" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."受付時間" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."担当者名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_事業者連絡先"."電話番号" IS 'Notion型: phone_number';

CREATE TABLE "lifedb_dummy"."[生活]_光熱水料金履歴" (
  "_page_id" uuid PRIMARY KEY,
  "使用日数" numeric,
  "使用量" numeric,
  "使用量単位" text,
  "備考" text,
  "再エネSC" numeric,
  "取込元" text,
  "基本料金" numeric,
  "対象年月" text,
  "検針終了日" jsonb,
  "検針開始日" jsonb,
  "消費税" numeric,
  "燃料費調整単価" numeric,
  "燃料費調整額" numeric,
  "記録ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "記録名" text,
  "請求金額" numeric,
  "電力量料金" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_光熱水料金履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."使用日数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."使用量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."使用量単位" IS 'Notion型: select / 選択肢: kWh | m³';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."再エネSC" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."取込元" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."基本料金" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."対象年月" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."検針終了日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."検針開始日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."消費税" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."燃料費調整単価" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."燃料費調整額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."記録ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."記録名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."請求金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水料金履歴"."電力量料金" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[生活]_光熱水関連" (
  "_page_id" uuid PRIMARY KEY,
  "お客さま番号" text,
  "使用場所住所" text,
  "備考" text,
  "利用日傾向" text,
  "名前" text,
  "契約名義" text,
  "契約容量" numeric,
  "契約種別" text,
  "支払方法" text,
  "検針日程" numeric,
  "種別" text
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_光熱水関連" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."お客さま番号" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."使用場所住所" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."利用日傾向" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."契約名義" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."契約容量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."契約種別" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."支払方法" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."検針日程" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_光熱水関連"."種別" IS 'Notion型: select / 選択肢: 電気 | ガス | 水道 | その他';

CREATE TABLE "lifedb_dummy"."[生活]_車整備履歴" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "内容" text,
  "区分" text,
  "実施店" text,
  "実施日" jsonb,
  "次回予定日" jsonb,
  "次回予定距離km" numeric,
  "記録名" text,
  "費用" numeric,
  "走行距離km" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[生活]_車整備履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."区分" IS 'Notion型: select / 選択肢: 点検 | 整備 | 部品交換 | 車検 | 修理 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."実施店" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."実施日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."次回予定日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."次回予定距離km" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."記録名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."費用" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[生活]_車整備履歴"."走行距離km" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[管理]_カード_支払い" (
  "_page_id" uuid PRIMARY KEY,
  "アカウント" text,
  "ウェブサイト" text,
  "カードID" text,
  "カード名称" text,
  "カード種別" text,
  "使用区分" text,
  "備考" text,
  "内容" text,
  "名前" text,
  "契約満了日" text,
  "契約開始日" text,
  "年会費" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_カード_支払い" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."アカウント" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."ウェブサイト" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."カードID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."カード名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."カード種別" IS 'Notion型: select / 選択肢: クレジットカード | ETCカード | Pay';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."使用区分" IS 'Notion型: select / 選択肢: 利用中';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."契約満了日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."契約開始日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_カード_支払い"."年会費" IS 'Notion型: select / 選択肢: 無料';

CREATE TABLE "lifedb_dummy"."[管理]_ドキュメント" (
  "_page_id" uuid PRIMARY KEY,
  "Created" timestamptz,
  "Current Path" text,
  "Document Date" jsonb,
  "Document ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "Document Type" text,
  "Last Edited" timestamptz,
  "Log ID" text,
  "Notion Page ID" text,
  "Source URL" text,
  "Status" text,
  "UUID" text,
  "表示名" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_ドキュメント" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Created" IS 'Notion型: created_time';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Current Path" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Document Date" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Document ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Document Type" IS 'Notion型: select / 選択肢: LifeLog | LifeOS | Other';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Last Edited" IS 'Notion型: last_edited_time';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Log ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Notion Page ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Source URL" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."Status" IS 'Notion型: select / 選択肢: Active | Archived';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."UUID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ドキュメント"."表示名" IS 'Notion型: title';

CREATE TABLE "lifedb_dummy"."[管理]_ネットワークIF" (
  "_page_id" uuid PRIMARY KEY,
  "IF種別" text,
  "IPアドレス" text,
  "IP設定" text,
  "MACアドレス" text,
  "SSID・接続先" text,
  "ネットワークIF ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "ホスト名" text,
  "使用状態" text,
  "備考" text,
  "帯域" text,
  "最終確認日" jsonb,
  "確認状態" text,
  "管理URL" text,
  "表示名" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_ネットワークIF" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."IF種別" IS 'Notion型: select / 選択肢: Wi-Fi | Ethernet | Bluetooth | Cellular | Other';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."IPアドレス" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."IP設定" IS 'Notion型: select / 選択肢: DHCP | 固定 | 不明';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."MACアドレス" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."SSID・接続先" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."ネットワークIF ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."ホスト名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."使用状態" IS 'Notion型: select / 選択肢: 利用中 | 停止 | 不明';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."帯域" IS 'Notion型: select / 選択肢: 2.4GHz | 5GHz | 6GHz | 該当なし';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."最終確認日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."確認状態" IS 'Notion型: select / 選択肢: 確定 | 要確認 | 不明';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."管理URL" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_ネットワークIF"."表示名" IS 'Notion型: title';

CREATE TABLE "lifedb_dummy"."[管理]_モノ全般" (
  "_page_id" uuid PRIMARY KEY,
  "シリアルNo" text,
  "メーカー" text,
  "モノID" text,
  "使用区分" text,
  "保証期間" text,
  "保証期間終了日" text,
  "備考" text,
  "内容" text,
  "名前" text,
  "名称" text,
  "型番" text,
  "種別" text,
  "購入元" text,
  "購入日" text,
  "購入金額" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_モノ全般" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."シリアルNo" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."メーカー" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."モノID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."使用区分" IS 'Notion型: select / 選択肢: 利用中 | 廃棄';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."保証期間" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."保証期間終了日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."型番" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."種別" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."購入元" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."購入日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_モノ全般"."購入金額" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[管理]_免許・資格検定" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "区分" text,
  "取得日" jsonb,
  "取得結果" text,
  "取得費用" numeric,
  "名前" text,
  "更新要否" boolean,
  "有効期限" jsonb,
  "次回更新日" jsonb,
  "状態" text,
  "発行・実施機関" text,
  "級・レベル" text,
  "証明書保管先" text,
  "資格・検定名" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_免許・資格検定" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."区分" IS 'Notion型: select / 選択肢: 運転免許 | 国家資格 | 技能講習 | 特別教育 | 民間資格 | 検定 | 語学 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."取得日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."取得結果" IS 'Notion型: select / 選択肢: 取得 | 合格 | 修了 | 認定';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."取得費用" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."更新要否" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."有効期限" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."次回更新日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."状態" IS 'Notion型: select / 選択肢: 有効 | 期限切れ | 失効 | 更新不要';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."発行・実施機関" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."級・レベル" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."証明書保管先" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_免許・資格検定"."資格・検定名" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[管理]_勤務履歴" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "入社日" jsonb,
  "勤務先Webサイト" text,
  "勤務先名" text,
  "勤務先情報" text,
  "勤務先所在地" text,
  "勤務先正式名称" text,
  "勤務先電話番号" text,
  "勤務地" text,
  "勤務履歴名" text,
  "在籍中" boolean,
  "役職" text,
  "所属部署" text,
  "退社日" jsonb,
  "雇用形態" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_勤務履歴" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."入社日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務先Webサイト" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務先名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務先情報" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務先所在地" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務先正式名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務先電話番号" IS 'Notion型: phone_number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務地" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."勤務履歴名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."在籍中" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."役職" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."所属部署" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."退社日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_勤務履歴"."雇用形態" IS 'Notion型: select / 選択肢: 正社員 | 契約社員 | 派遣社員 | パート・アルバイト | 役員 | 自営業 | その他';

CREATE TABLE "lifedb_dummy"."[管理]_投資原資" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "区分" text,
  "原資ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "原資名" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_投資原資" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_投資原資"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_投資原資"."区分" IS 'Notion型: select / 選択肢: 家計 | 個人 | 贈与由来 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_投資原資"."原資ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_投資原資"."原資名" IS 'Notion型: title';

CREATE TABLE "lifedb_dummy"."[管理]_物件" (
  "_page_id" uuid PRIMARY KEY,
  "住所" jsonb,
  "使用区分" text,
  "備考" text,
  "取得価格" numeric,
  "取得年月日" jsonb,
  "名前" text,
  "名称" text,
  "土地坪数" numeric,
  "土地面積" numeric,
  "在住期間" jsonb,
  "延床面積(1階)" numeric,
  "延床面積(2階)" numeric,
  "建物種別" text,
  "建築年月日" jsonb,
  "所有区分" text,
  "構造" text,
  "物件ID" text,
  "用途" text,
  "築年数" jsonb,
  "階数" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_物件" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."住所" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."使用区分" IS 'Notion型: select / 選択肢: 利用中';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."取得価格" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."取得年月日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."土地坪数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."土地面積" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."在住期間" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."延床面積(1階)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."延床面積(2階)" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."建物種別" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."建築年月日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."所有区分" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."構造" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."物件ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."用途" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."築年数" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件"."階数" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[管理]_物件区画" (
  "_page_id" uuid PRIMARY KEY,
  "ステータス" text,
  "主採光方位" text,
  "位置区分" text,
  "備考" text,
  "名前" text,
  "名称" text,
  "天井高mm" numeric,
  "奥行mm" numeric,
  "用途" text,
  "畳数" numeric,
  "種別" text,
  "窓方位" text[],
  "詳細ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "間口幅mm" numeric,
  "階" numeric,
  "面積㎡" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_物件区画" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."ステータス" IS 'Notion型: select / 選択肢: 使用中 | 未使用 | 改装中 | 廃止';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."主採光方位" IS 'Notion型: select / 選択肢: 北 | 北東 | 東 | 南東 | 南 | 南西 | 西 | 北西 | なし';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."位置区分" IS 'Notion型: select / 選択肢: 北東角 | 南東角 | 南西角 | 北西角 | 北側 | 南側 | 東側 | 西側 | 中央 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."天井高mm" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."奥行mm" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."用途" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."畳数" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."種別" IS 'Notion型: select / 選択肢: 部屋 | カーポート | 庭 | 駐車場 | 玄関 | 廊下 | 収納 | バルコニー | 階段 | 屋根裏 | 外周スペース | その他';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."窓方位" IS 'Notion型: multi_select / 選択肢: 北 | 北東 | 東 | 南東 | 南 | 南西 | 西 | 北西';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."詳細ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."間口幅mm" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."階" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_物件区画"."面積㎡" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[管理]_車両" (
  "_page_id" uuid PRIMARY KEY,
  "ひらがな" text,
  "一連指定番号" numeric,
  "乗車定員" text,
  "使用区分" text,
  "備考" text,
  "備考(車検証の備考)" text,
  "分類番号" numeric,
  "初度検査年月" text,
  "前前軸重" numeric,
  "前後軸重" text,
  "原動機の型式" text,
  "名前" text,
  "名称" text,
  "地名" text,
  "型式" text,
  "型式指定番号" numeric,
  "幅" numeric,
  "年式計算用" jsonb,
  "年数" jsonb,
  "後前軸重" text,
  "後後軸重" numeric,
  "担当" text,
  "最大積載量" text,
  "燃料の種類" text,
  "用途" text,
  "総排気量又は定格出力" numeric,
  "自動車の種別" text,
  "自家用・事業用の別" text,
  "自賠責保険" jsonb,
  "購入店" text,
  "購入金額" numeric,
  "車ID" text,
  "車両総重量" text,
  "車両重量" numeric,
  "車体の形状" text,
  "車体番号" text,
  "車名" text,
  "車検証" jsonb,
  "長さ" numeric,
  "類別区分番号" text,
  "高さ" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_車両" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."ひらがな" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."一連指定番号" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."乗車定員" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."使用区分" IS 'Notion型: select / 選択肢: 利用中 | 売却済';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."備考(車検証の備考)" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."分類番号" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."初度検査年月" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."前前軸重" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."前後軸重" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."原動機の型式" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."地名" IS 'Notion型: select / 選択肢: 地域A';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."型式" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."型式指定番号" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."幅" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."年式計算用" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."年数" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."後前軸重" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."後後軸重" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."担当" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."最大積載量" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."燃料の種類" IS 'Notion型: select / 選択肢: ガソリン';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."用途" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."総排気量又は定格出力" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."自動車の種別" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."自家用・事業用の別" IS 'Notion型: select / 選択肢: 自家用';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."自賠責保険" IS 'Notion型: file';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."購入店" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."購入金額" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車両総重量" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車両重量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車体の形状" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車体番号" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車名" IS 'Notion型: select / 選択肢: ホンダ | ダイハツ';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."車検証" IS 'Notion型: file';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."長さ" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."類別区分番号" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_車両"."高さ" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[管理]_金融商品" (
  "_page_id" uuid PRIMARY KEY,
  "価格単位" text,
  "備考" text,
  "商品ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "商品名" text,
  "商品種別" text,
  "市場" text,
  "銘柄コード" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_金融商品" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."価格単位" IS 'Notion型: select / 選択肢: 円/1万口 | 円/株 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."商品ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."商品名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."商品種別" IS 'Notion型: select / 選択肢: 投資信託 | 国内株式 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."市場" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_金融商品"."銘柄コード" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."[管理]_銀行" (
  "_page_id" uuid PRIMARY KEY,
  "バンクID" text,
  "バンク名称" text,
  "使用区分" text,
  "備考" text,
  "内容" text,
  "名前" text,
  "契約満了日" text,
  "契約開始日" text,
  "年会費" text,
  "詳細区分" text
);
COMMENT ON TABLE "lifedb_dummy"."[管理]_銀行" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."バンクID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."バンク名称" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."使用区分" IS 'Notion型: select / 選択肢: 利用中';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."内容" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."契約満了日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."契約開始日" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."年会費" IS 'Notion型: select / 選択肢: 無料';
COMMENT ON COLUMN "lifedb_dummy"."[管理]_銀行"."詳細区分" IS 'Notion型: select / 選択肢: キャッシュカード | 証券';

CREATE TABLE "lifedb_dummy"."[関係]_ドキュメント関連" (
  "_page_id" uuid PRIMARY KEY,
  "Document ID" text,
  "Document URL" text,
  "Edge ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "LifeLog ID" text,
  "対象DB" text,
  "対象URL" text,
  "対象レコードID" text,
  "対象レコード名" text,
  "文脈" text,
  "状態" text,
  "発生日" jsonb,
  "登録元" text,
  "関係名" text,
  "関係種別" text
);
COMMENT ON TABLE "lifedb_dummy"."[関係]_ドキュメント関連" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."Document ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."Document URL" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."Edge ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."LifeLog ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."対象DB" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."対象URL" IS 'Notion型: url';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."対象レコードID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."対象レコード名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."文脈" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."状態" IS 'Notion型: select / 選択肢: 有効 | 要確認 | 無効';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."発生日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."登録元" IS 'Notion型: select / 選択肢: 自動整合化 | 手動';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."関係名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_ドキュメント関連"."関係種別" IS 'Notion型: select / 選択肢: 対象 | 登場 | 根拠 | 更新元 | 関連';

CREATE TABLE "lifedb_dummy"."[関係]_投資取引原資" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "取引キー" text,
  "配賦ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "配賦名" text,
  "配賦数量" numeric,
  "配賦方法" text,
  "配賦率" numeric,
  "配賦金額" numeric
);
COMMENT ON TABLE "lifedb_dummy"."[関係]_投資取引原資" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."取引キー" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."配賦ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."配賦名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."配賦数量" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."配賦方法" IS 'Notion型: select / 選択肢: 旧Excel確定 | 分配金按分 | 手動 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."配賦率" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_投資取引原資"."配賦金額" IS 'Notion型: number';

CREATE TABLE "lifedb_dummy"."[関係]_親子" (
  "_page_id" uuid PRIMARY KEY,
  "備考" text,
  "根拠" text,
  "確度" text,
  "血縁" boolean,
  "親子ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "関係名" text,
  "関係種別" text
);
COMMENT ON TABLE "lifedb_dummy"."[関係]_親子" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."根拠" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."確度" IS 'Notion型: select / 選択肢: 確定 | 推定 | 要確認';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."血縁" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."親子ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."関係名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_親子"."関係種別" IS 'Notion型: select / 選択肢: 実親子 | 養親子 | 継親子 | 不明';

CREATE TABLE "lifedb_dummy"."[関係]_関係者" (
  "_page_id" uuid PRIMARY KEY,
  "ニックネーム" text,
  "メール1" text,
  "メール2" text,
  "人物DB昇格候補" boolean,
  "会社" text,
  "個人" text,
  "備考" text,
  "内線" text,
  "年齢備考" text,
  "年齢確認年月日" jsonb,
  "役職・立場" text,
  "性別" text,
  "所属" text,
  "携帯" text,
  "更新日時" timestamptz,
  "氏名" text,
  "氏名カナ" text,
  "現在年齢" jsonb,
  "現在関係あり" boolean,
  "登録日時" timestamptz,
  "確認時年齢" numeric,
  "連絡先メモ" text,
  "部署名" text,
  "重要度" text,
  "関係カテゴリ" text,
  "関係性" text,
  "関係終了日" jsonb,
  "関係者ID" bigint GENERATED BY DEFAULT AS IDENTITY,
  "関係開始日" jsonb,
  "電話" text
);
COMMENT ON TABLE "lifedb_dummy"."[関係]_関係者" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."ニックネーム" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."メール1" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."メール2" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."人物DB昇格候補" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."会社" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."個人" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."内線" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."年齢備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."年齢確認年月日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."役職・立場" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."性別" IS 'Notion型: select / 選択肢: 男 | 女 | 不明';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."所属" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."携帯" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."更新日時" IS 'Notion型: last_edited_time';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."氏名" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."氏名カナ" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."現在年齢" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."現在関係あり" IS 'Notion型: checkbox';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."登録日時" IS 'Notion型: created_time';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."確認時年齢" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."連絡先メモ" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."部署名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."重要度" IS 'Notion型: select / 選択肢: 高 | 中 | 低';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."関係カテゴリ" IS 'Notion型: select / 選択肢: 友人 | 会社 | 学校 | 医療 | 業者 | 近隣 | その他';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."関係性" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."関係終了日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."関係者ID" IS 'Notion型: auto_increment_id';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."関係開始日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."[関係]_関係者"."電話" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."世帯" (
  "_page_id" uuid PRIMARY KEY,
  "世帯ID" text,
  "世帯主" text,
  "世帯主人物ID" text,
  "住所" text,
  "備考" text,
  "名前" text,
  "表示順" numeric,
  "郵便番号" text
);
COMMENT ON TABLE "lifedb_dummy"."世帯" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."世帯ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."世帯主" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."世帯主人物ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."住所" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."表示順" IS 'Notion型: number';
COMMENT ON COLUMN "lifedb_dummy"."世帯"."郵便番号" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."人物" (
  "_page_id" uuid PRIMARY KEY,
  "ふりがな(名)" text,
  "ふりがな(姓)" text,
  "ニックネーム" text,
  "メールアドレス" text,
  "世帯ID" jsonb,
  "世帯_表示順" jsonb,
  "享年" jsonb,
  "人物ID" text,
  "住所" jsonb,
  "備考" text,
  "名" text,
  "名前" text,
  "命日" jsonb,
  "命日経過年月" jsonb,
  "場所" jsonb,
  "姓" text,
  "年齢" jsonb,
  "性別" text,
  "生年月日" jsonb,
  "生年月日(和暦)" jsonb,
  "続柄" text,
  "血液型" text,
  "誕生日メール通知フラグ" text,
  "電話番号" text
);
COMMENT ON TABLE "lifedb_dummy"."人物" IS '匿名化したNotionスキーマ。Relationは専用中間テーブル参照。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."ふりがな(名)" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."ふりがな(姓)" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."ニックネーム" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."メールアドレス" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."世帯ID" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."世帯_表示順" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."享年" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."人物ID" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."住所" IS 'Notion型: rollup / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."備考" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."名" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."名前" IS 'Notion型: title';
COMMENT ON COLUMN "lifedb_dummy"."人物"."命日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."人物"."命日経過年月" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."場所" IS 'Notion型: place';
COMMENT ON COLUMN "lifedb_dummy"."人物"."姓" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."年齢" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."性別" IS 'Notion型: select / 選択肢: 男 | 女';
COMMENT ON COLUMN "lifedb_dummy"."人物"."生年月日" IS 'Notion型: date / 日付・日時・期間を保持: {start, end, time_zone}';
COMMENT ON COLUMN "lifedb_dummy"."人物"."生年月日(和暦)" IS 'Notion型: formula / 結果保存用。元式を取得できないため自動計算なし。JSON文字列・数値・配列等を保存。';
COMMENT ON COLUMN "lifedb_dummy"."人物"."続柄" IS 'Notion型: text';
COMMENT ON COLUMN "lifedb_dummy"."人物"."血液型" IS 'Notion型: select / 選択肢: B | A | O';
COMMENT ON COLUMN "lifedb_dummy"."人物"."誕生日メール通知フラグ" IS 'Notion型: select / 選択肢: TRUE';
COMMENT ON COLUMN "lifedb_dummy"."人物"."電話番号" IS 'Notion型: text';

CREATE TABLE "lifedb_dummy"."relation_001" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]_生命医療火災保険" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_001_target_idx" ON "lifedb_dummy"."relation_001" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_001" IS '[保険]_生命医療火災保険 / 被保険者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_002" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]自動車保険" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_002_target_idx" ON "lifedb_dummy"."relation_002" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_002" IS '[保険]自動車保険 / 契約者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_003" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]自動車保険" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_003_target_idx" ON "lifedb_dummy"."relation_003" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_003" IS '[保険]自動車保険 / 支払い方法 → [管理]_カード_支払い。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_004" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]自動車保険" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_車両" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_004_target_idx" ON "lifedb_dummy"."relation_004" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_004" IS '[保険]自動車保険 / 車両 → [管理]_車両。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_005" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_予防接種" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_005_target_idx" ON "lifedb_dummy"."relation_005" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_005" IS '[健康]_予防接種 / 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_006" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_健康診断結果" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_検査項目マスタ" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_006_target_idx" ON "lifedb_dummy"."relation_006" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_006" IS '[健康]_健康診断結果 / 検査項目マスタ → [健康]_検査項目マスタ。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_007" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_健康診断結果" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_007_target_idx" ON "lifedb_dummy"."relation_007" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_007" IS '[健康]_健康診断結果 / 🙋 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_008" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_成長記録" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_008_target_idx" ON "lifedb_dummy"."relation_008" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_008" IS '[健康]_成長記録 / 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_009" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_検査項目マスタ" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]_健康診断結果" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_009_target_idx" ON "lifedb_dummy"."relation_009" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_009" IS '[健康]_検査項目マスタ / 健康診断結果 → [健康]_健康診断結果。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_010" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]医療疾患管理" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_010_target_idx" ON "lifedb_dummy"."relation_010" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_010" IS '[健康]医療疾患管理 / 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_011" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]医療疾患管理" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]医療経過" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_011_target_idx" ON "lifedb_dummy"."relation_011" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_011" IS '[健康]医療疾患管理 / 医療経過 → [健康]医療経過。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_012" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]医療経過" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]医療疾患管理" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_012_target_idx" ON "lifedb_dummy"."relation_012" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_012" IS '[健康]医療経過 / 疾患 → [健康]医療疾患管理。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_013" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[分析]_用語マスタ" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[分析]_用語履歴" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_013_target_idx" ON "lifedb_dummy"."relation_013" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_013" IS '[分析]_用語マスタ / 出現履歴 → [分析]_用語履歴。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_014" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[分析]_用語履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[分析]_用語マスタ" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_014_target_idx" ON "lifedb_dummy"."relation_014" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_014" IS '[分析]_用語履歴 / 用語 → [分析]_用語マスタ。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_015" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_テスト" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_在籍" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_015_target_idx" ON "lifedb_dummy"."relation_015" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_015" IS '[学校]_テスト / 学校在籍 → [学校]_在籍。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_016" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_在籍" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_016_target_idx" ON "lifedb_dummy"."relation_016" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_016" IS '[学校]_在籍 / 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_017" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_在籍" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_学校" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_017_target_idx" ON "lifedb_dummy"."relation_017" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_017" IS '[学校]_在籍 / 学校 → [学校]_学校。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_018" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_学校" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_在籍" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_018_target_idx" ON "lifedb_dummy"."relation_018" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_018" IS '[学校]_学校 / 📔 [学校]_在籍 → [学校]_在籍。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_019" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_評定" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[学校]_在籍" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_019_target_idx" ON "lifedb_dummy"."relation_019" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_019" IS '[学校]_評定 / 学校在籍 → [学校]_在籍。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_020" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_ふるさと納税" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_020_target_idx" ON "lifedb_dummy"."relation_020" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_020" IS '[家計]_ふるさと納税 / 寄付者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_021" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_カード明細" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_021_target_idx" ON "lifedb_dummy"."relation_021" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_021" IS '[家計]_カード明細 / カード → [管理]_カード_支払い。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_022" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_家計固定費・支払予定" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_022_target_idx" ON "lifedb_dummy"."relation_022" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_022" IS '[家計]_家計固定費・支払予定 / カード → [管理]_カード_支払い。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_023" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_家計固定費・支払予定" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_事業者連絡先" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_023_target_idx" ON "lifedb_dummy"."relation_023" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_023" IS '[家計]_家計固定費・支払予定 / 契約先 → [生活]_事業者連絡先。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_024" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_家計固定費・支払予定" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_024_target_idx" ON "lifedb_dummy"."relation_024" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_024" IS '[家計]_家計固定費・支払予定 / 対象者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_025" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_家計固定費・支払予定" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_025_target_idx" ON "lifedb_dummy"."relation_025" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_025" IS '[家計]_家計固定費・支払予定 / 銀行口座 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_026" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資保有集計" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_投資原資" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_026_target_idx" ON "lifedb_dummy"."relation_026" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_026" IS '[家計]_投資保有集計 / 主原資 → [管理]_投資原資。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_027" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資保有集計" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資取引" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_027_target_idx" ON "lifedb_dummy"."relation_027" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_027" IS '[家計]_投資保有集計 / 投資取引 → [家計]_投資取引。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_028" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資保有集計" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_028_target_idx" ON "lifedb_dummy"."relation_028" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_028" IS '[家計]_投資保有集計 / 金融口座 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_029" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資保有集計" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_金融商品" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_029_target_idx" ON "lifedb_dummy"."relation_029" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_029" IS '[家計]_投資保有集計 / 金融商品 → [管理]_金融商品。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_030" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資原資基準残高" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_投資原資" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_030_target_idx" ON "lifedb_dummy"."relation_030" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_030" IS '[家計]_投資原資基準残高 / 投資原資 → [管理]_投資原資。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_031" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資原資基準残高" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_031_target_idx" ON "lifedb_dummy"."relation_031" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_031" IS '[家計]_投資原資基準残高 / 金融口座 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_032" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資原資基準残高" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_金融商品" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_032_target_idx" ON "lifedb_dummy"."relation_032" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_032" IS '[家計]_投資原資基準残高 / 金融商品 → [管理]_金融商品。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_033" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資取引" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_投資原資" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_033_target_idx" ON "lifedb_dummy"."relation_033" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_033" IS '[家計]_投資取引 / 主原資 → [管理]_投資原資。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_034" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資取引" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[関係]_投資取引原資" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_034_target_idx" ON "lifedb_dummy"."relation_034" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_034" IS '[家計]_投資取引 / 原資配賦 → [関係]_投資取引原資。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_035" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資取引" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_035_target_idx" ON "lifedb_dummy"."relation_035" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_035" IS '[家計]_投資取引 / 金融口座 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_036" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資取引" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_金融商品" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_036_target_idx" ON "lifedb_dummy"."relation_036" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_036" IS '[家計]_投資取引 / 金融商品 → [管理]_金融商品。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_037" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_給与年次" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_給与明細" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_037_target_idx" ON "lifedb_dummy"."relation_037" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_037" IS '[家計]_給与年次 / 給与明細 → [家計]_給与明細。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_038" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_給与明細" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_給与年次" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_038_target_idx" ON "lifedb_dummy"."relation_038" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_038" IS '[家計]_給与明細 / 年次 → [家計]_給与年次。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_039" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_資産残高履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_039_target_idx" ON "lifedb_dummy"."relation_039" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_039" IS '[家計]_資産残高履歴 / 金融口座 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_040" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_金融商品価格履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_金融商品" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_040_target_idx" ON "lifedb_dummy"."relation_040" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_040" IS '[家計]_金融商品価格履歴 / 金融商品 → [管理]_金融商品。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_041" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_イベント" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_041_target_idx" ON "lifedb_dummy"."relation_041" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_041" IS '[生活]_イベント / 対象者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_042" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_イベント" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_042_target_idx" ON "lifedb_dummy"."relation_042" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_042" IS '[生活]_イベント / 担当者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_043" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_サブスク" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_043_target_idx" ON "lifedb_dummy"."relation_043" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_043" IS '[生活]_サブスク / 利用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_044" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_サブスク" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_044_target_idx" ON "lifedb_dummy"."relation_044" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_044" IS '[生活]_サブスク / 契約者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_045" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_モバイル契約" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_045_target_idx" ON "lifedb_dummy"."relation_045" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_045" IS '[生活]_モバイル契約 / 利用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_046" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_モバイル契約" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_046_target_idx" ON "lifedb_dummy"."relation_046" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_046" IS '[生活]_モバイル契約 / 契約者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_047" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_モバイル契約" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_047_target_idx" ON "lifedb_dummy"."relation_047" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_047" IS '[生活]_モバイル契約 / 支払い名義 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_048" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_モバイル契約" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_048_target_idx" ON "lifedb_dummy"."relation_048" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_048" IS '[生活]_モバイル契約 / 支払方法 → [管理]_カード_支払い。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_049" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_不動産修繕履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_049_target_idx" ON "lifedb_dummy"."relation_049" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_049" IS '[生活]_不動産修繕履歴 / モノ → [管理]_モノ全般。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_050" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_不動産修繕履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_050_target_idx" ON "lifedb_dummy"."relation_050" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_050" IS '[生活]_不動産修繕履歴 / 不動産 → [管理]_物件。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_051" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_事業者連絡先" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_051_target_idx" ON "lifedb_dummy"."relation_051" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_051" IS '[生活]_事業者連絡先 / 契約者・利用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_052" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_光熱水料金履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_光熱水関連" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_052_target_idx" ON "lifedb_dummy"."relation_052" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_052" IS '[生活]_光熱水料金履歴 / 光熱水契約 → [生活]_光熱水関連。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_053" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_光熱水関連" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_光熱水料金履歴" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_053_target_idx" ON "lifedb_dummy"."relation_053" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_053" IS '[生活]_光熱水関連 / 料金履歴 → [生活]_光熱水料金履歴。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_054" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_車整備履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_車両" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_054_target_idx" ON "lifedb_dummy"."relation_054" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_054" IS '[生活]_車整備履歴 / 車 → [管理]_車両。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_055" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_モバイル契約" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_055_target_idx" ON "lifedb_dummy"."relation_055" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_055" IS '[管理]_カード_支払い / モバイル契約 → [生活]_モバイル契約。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_056" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_056_target_idx" ON "lifedb_dummy"."relation_056" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_056" IS '[管理]_カード_支払い / 利用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_057" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_057_target_idx" ON "lifedb_dummy"."relation_057" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_057" IS '[管理]_カード_支払い / 契約者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_058" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_058_target_idx" ON "lifedb_dummy"."relation_058" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_058" IS '[管理]_カード_支払い / 引落し先 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_059" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]自動車保険" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_059_target_idx" ON "lifedb_dummy"."relation_059" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_059" IS '[管理]_カード_支払い / 🛞 [保険]自動車保険 → [保険]自動車保険。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_060" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_ネットワークIF" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_060_target_idx" ON "lifedb_dummy"."relation_060" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_060" IS '[管理]_ネットワークIF / モノ → [管理]_モノ全般。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_061" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_ネットワークIF" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_061_target_idx" ON "lifedb_dummy"."relation_061" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_061" IS '[管理]_モノ全般 / ネットワークIF → [管理]_ネットワークIF。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_062" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."世帯" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_062_target_idx" ON "lifedb_dummy"."relation_062" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_062" IS '[管理]_モノ全般 / 世帯 → 世帯。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_063" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_063_target_idx" ON "lifedb_dummy"."relation_063" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_063" IS '[管理]_モノ全般 / 利用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_064" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_064_target_idx" ON "lifedb_dummy"."relation_064" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_064" IS '[管理]_モノ全般 / 物件 → [管理]_物件。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_065" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件区画" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_065_target_idx" ON "lifedb_dummy"."relation_065" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_065" IS '[管理]_モノ全般 / 物件区画 → [管理]_物件区画。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_066" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_免許・資格検定" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_066_target_idx" ON "lifedb_dummy"."relation_066" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_066" IS '[管理]_免許・資格検定 / 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_067" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_勤務履歴" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_067_target_idx" ON "lifedb_dummy"."relation_067" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_067" IS '[管理]_勤務履歴 / 人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_068" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."世帯" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_068_target_idx" ON "lifedb_dummy"."relation_068" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_068" IS '[管理]_物件 / 世帯 → 世帯。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_069" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]_生命医療火災保険" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_069_target_idx" ON "lifedb_dummy"."relation_069" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_069" IS '[管理]_物件 / 保険 → [保険]_生命医療火災保険。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_070" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_070_target_idx" ON "lifedb_dummy"."relation_070" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_070" IS '[管理]_物件 / 所有者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_071" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件区画" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_071_target_idx" ON "lifedb_dummy"."relation_071" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_071" IS '[管理]_物件区画 / 所属物件 → [管理]_物件。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_072" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_車両" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_072_target_idx" ON "lifedb_dummy"."relation_072" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_072" IS '[管理]_車両 / 使用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_073" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_車両" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_073_target_idx" ON "lifedb_dummy"."relation_073" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_073" IS '[管理]_車両 / 所有者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_074" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_車両" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]自動車保険" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_074_target_idx" ON "lifedb_dummy"."relation_074" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_074" IS '[管理]_車両 / 🛞 [保険]自動車保険 → [保険]自動車保険。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_075" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_075_target_idx" ON "lifedb_dummy"."relation_075" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_075" IS '[管理]_銀行 / カード_支払い → [管理]_カード_支払い。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_076" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_076_target_idx" ON "lifedb_dummy"."relation_076" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_076" IS '[管理]_銀行 / 利用者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_077" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_077_target_idx" ON "lifedb_dummy"."relation_077" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_077" IS '[管理]_銀行 / 契約者 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_078" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[関係]_投資取引原資" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_投資原資" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_078_target_idx" ON "lifedb_dummy"."relation_078" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_078" IS '[関係]_投資取引原資 / 投資原資 → [管理]_投資原資。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_079" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[関係]_投資取引原資" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[家計]_投資取引" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_079_target_idx" ON "lifedb_dummy"."relation_079" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_079" IS '[関係]_投資取引原資 / 投資取引 → [家計]_投資取引。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_080" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[関係]_親子" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_080_target_idx" ON "lifedb_dummy"."relation_080" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_080" IS '[関係]_親子 / 子 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_081" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[関係]_親子" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_081_target_idx" ON "lifedb_dummy"."relation_081" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_081" IS '[関係]_親子 / 親 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_082" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[関係]_関係者" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_082_target_idx" ON "lifedb_dummy"."relation_082" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_082" IS '[関係]_関係者 / 関連人物 → 人物。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_083" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."世帯" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_物件" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_083_target_idx" ON "lifedb_dummy"."relation_083" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_083" IS '世帯 / 不動産 → [管理]_物件。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_084" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_カード_支払い" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_084_target_idx" ON "lifedb_dummy"."relation_084" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_084" IS '人物 / カード → [管理]_カード_支払い。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_085" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_サブスク" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_085_target_idx" ON "lifedb_dummy"."relation_085" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_085" IS '人物 / サブスク → [生活]_サブスク。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_086" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_モノ全般" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_086_target_idx" ON "lifedb_dummy"."relation_086" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_086" IS '人物 / モノ → [管理]_モノ全般。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_087" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[生活]_モバイル契約" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_087_target_idx" ON "lifedb_dummy"."relation_087" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_087" IS '人物 / モバイル契約 → [生活]_モバイル契約。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_088" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."世帯" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_088_target_idx" ON "lifedb_dummy"."relation_088" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_088" IS '人物 / 世帯 → 世帯。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_089" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[保険]_生命医療火災保険" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_089_target_idx" ON "lifedb_dummy"."relation_089" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_089" IS '人物 / 保険 → [保険]_生命医療火災保険。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_090" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[健康]医療疾患管理" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_090_target_idx" ON "lifedb_dummy"."relation_090" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_090" IS '人物 / 医療疾患 → [健康]医療疾患管理。複数参照。双方向プロパティは別々に保存。';

CREATE TABLE "lifedb_dummy"."relation_091" (
  source_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."人物" ("_page_id") ON DELETE CASCADE,
  target_page_id uuid NOT NULL REFERENCES "lifedb_dummy"."[管理]_銀行" ("_page_id") ON DELETE CASCADE,
  PRIMARY KEY (source_page_id, target_page_id)
);
CREATE INDEX "relation_091_target_idx" ON "lifedb_dummy"."relation_091" (target_page_id);
COMMENT ON TABLE "lifedb_dummy"."relation_091" IS '人物 / 銀行 → [管理]_銀行。複数参照。双方向プロパティは別々に保存。';

COMMIT;
